package com.cg.payroll.main;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		/*try {

			PayrollServices payrollServices = new PayrollServicesImpl();
			int newId=payrollServices.acceptAssociateDetails("Samykya", "Thanuku", "jsusjks", "sfgd", "dv", "djhg", 150000,30000,1000,1000, 212, "CITI", "CITI00005") ;
			System.out.println("Associate ID=" +newId);
			Associate a=payrollServices.getAssociateDetails(newId);
			System.out.println("Name of the associate is " +a.getFirstName()+ " " +a.getLastName());
			Associate a1=payrollServices.getAssociateDetails(newId);
			System.out.println("Basic Salary=" +a1.getSalary().getBasicSalary());
			float y = payrollServices.calculateNetSalary(newId);
			System.out.println("NetSalary=" +y);
			Associate a2=payrollServices.getAssociateDetails(newId);
			System.out.println("Monthly tax= " +a2.getSalary().getMonthlyTax());
		}
		catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
	}
		 */
		try {
			PayrollServicesImpl payrollServices=new PayrollServicesImpl();
			int associateID;
			int key=0;
			Scanner scanner =new Scanner (System.in);
			while(key!=6){
				System.out.print("Enter 1 : Insert New employee"+"\n"+"2 : To get Associate Details of employee"+"\n"+
						"3 : To get  All Associate Details of employee/"+"\n"+"4 : To Calculate salary of employee"+"\n"+
						"5 : To delete an employee"+"\n"+"6 : Exit");
				key=scanner.nextInt();
				switch (key) {
			/*	case 1:
					associateID= payrollServices.acceptAssociateDetails("Samykya", "Thanuku", "jr con", "training", "asdf123", "shishir@gmail.com", 150000, 30000, 1000, 1000, 123456, "HDFC", "HDFC1234");
					System.out.println(associateID);
					break;*/

				case 2: 
					System.out.println("Enter the AssociateId of employee to get the Details");
					associateID=scanner.nextInt();
					Associate associate2;
					associate2 = payrollServices.getAssociateDetails(associateID);
					System.out.println(associate2.toString());
					break;


				/*case 3: 
					System.out.println("Following are the Employee details of Entire Array");
					List<Associate> associate=payrollServices.getAssociateDetails();
					for(Associate associate1:associate)
						System.out.println(associate1);
					break;*/


				case 4: 
					System.out.println("Enter the AssociateId of employee to calculate the salary");
					associateID=scanner.nextInt();
					System.out.println(payrollServices.calculateNetSalary(associateID));
					break;

					case 5:
					System.out.println("Enter the AssociateId of employee to be deleted");
					associateID=scanner.nextInt();
					Associate associate1=payrollServices.getAssociateDetails(associateID);
					System.out.println(payrollServices.delete(associate1));

				case 6: 
					System.out.println("Exit");
					break;
				default:
					break;
				}
			}
		}
		catch (AssociateDetailsNotFoundException e){
			e.printStackTrace();

		}
	}
}
