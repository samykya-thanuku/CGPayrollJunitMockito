package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.MockingDetails;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {

	private static PayrollServices payrollservices;
	private static PayrollDAOServices mockDaoServices;
	
	
	@BeforeClass
	public static void setUpTestEnv(){
		mockDaoServices=Mockito.mock(PayrollDAOServices.class);
		payrollservices=new PayrollServicesImpl(mockDaoServices);
		
	}

	@Before 
	public  void setUpMockData(){
		
		Associate associate1=new Associate(1001, 12000, "mani", "reddy", "eee", "analyst", "FYT566", "mani.com", new Salary(230000, 10000, 19000), new BankDetails(1234, "xyz", "FYTGH256365"));
		Associate associate2=new Associate(1002, 13000, "sam", "reddy", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		ArrayList<Associate>associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		Associate associate3=new Associate( 13000, "sam", "reddy", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		Mockito.when(mockDaoServices.getAssociate(1001)).thenReturn(associate1);
		Mockito.when(mockDaoServices.getAssociate(1002)).thenReturn(associate2);
	//	Mockito.when(mockDaoServices.getAssociate(1003)).thenReturn(associate3);
		
		Mockito.when(mockDaoServices.getAssociate(1234)).thenReturn(null);
		Mockito.when(mockDaoServices.insertAssociate(associate3)).thenReturn(1003);
		Mockito.when(mockDaoServices.getAssociates()).thenReturn(associateList);
	}
	@Test
	public void validAssociateDetails() throws AssociateDetailsNotFoundException{
		//Mockito.verify(mockDaoServices).getAssociate(Mockito.anyInt());	
		Associate expectedassociate=payrollservices.getAssociateDetails(1001);
		Associate actualassociate=new Associate(1001, 12000, "mani", "reddy", "eee", "analyst", "FYT566", "mani.com", new Salary(230000, 10000, 19000), new BankDetails(1234, "xyz", "FYTGH256365"));
	
		assertEquals(expectedassociate, actualassociate);
		
	}

	@Test(expected=AssociateDetailsNotFoundException.class)
	public void inValidAssociateDetails() throws  AssociateDetailsNotFoundException
	{
		Associate expectedassociate=payrollservices.getAssociateDetails(1234);
		Associate actualassociate=new Associate(1001, 12000, "mani", "reddy", "eee", "analyst", "FYT566", "mani.com", new Salary(230000, 10000, 19000), new BankDetails(1234, "xyz", "FYTGH256365"));
		assertEquals(expectedassociate, actualassociate);
	
	}
	
	@Test
	public void acceptAssociateId() throws PayrollServicesDownException{
		Associate expectedassociate=new Associate( 13000, "sam", "reddy", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		int actualId=payrollservices.acceptAssociateDetails("sam", "reddy","sam.com", "ece", "analyst", "FYT56667", 13000, 240000, 10404, 23000, 12345, "asd", "FYTGH223265");
	//	Mockito.verify(mockDaoServices).insertAssociate();
		
		assertEquals(1003, actualId);
	}
	
	@Test 
	public void netsalary() throws AssociateDetailsNotFoundException
	{
float expectedsalary = payrollservices.calculateNetSalary(1001);
float actualsalary=
	}

	@Test
	public void correctAssociateId() throws AssociateDetailsNotFoundException{

	}



	@After
	public  void tearDownMockData(){


	}

	@AfterClass
	public static void tearDownTestEnv(){


	}
}